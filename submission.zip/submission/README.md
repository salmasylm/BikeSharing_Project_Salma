# Bike Sharing Dashboard 

## Description
Bike sharing Dashboard ini dibuat untuk menyelesaikan tugas dari Proyek Akhir Belajar Analisa Data dengan Python, Kemudian ditampilkan di Streamlit berbentuk Dashboard

## Aplikasi yang digunakan
1. Google Colabs: Digunakan untuk awalan mengerjakan analisa data, dari dari data mentah hingga menjadi data yang siap di proses
2. VSC: Juga digunakan proses codingan python untuk Dashboard
3. Streamlit: Digunakan untuk membuat dashboard

## Run steamlit app
streamlit run dashboard.py (Lewat Lokal)

## Streamlit Cloud 
Link Streamlit Secara otomatis: https://bike-sharingproyek-dimas-mgshgrgkf5cg85pvzeyqgj.streamlit.app/
